// server.js

// 1. Gerekli paketleri çağır
const express = require('express');
const OpenAI = require('openai');
const cors = require('cors');
const multer = require('multer');
require('dotenv').config();

// 2. Uygulama ve ayarları yapılandır
const app = express();
const port = 3001;

app.use(cors());
app.use(express.json());

const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// 3. Ana Analiz Endpoint'i - KALICI ÇÖZÜM İLE
app.post('/api/analyze', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No image file uploaded.' });
    }

    console.log("Image received. Detecting file type from buffer...");

    // =================================================================
    // KALICI ÇÖZÜM: file-type kütüphanesini kullanarak MIME türünü tespit etme
    // Bu kütüphane CommonJS yerine ES Module kullandığı için dinamik import() ile çağırıyoruz.
    const { fileTypeFromBuffer } = await import('file-type');
    
    // Dosyanın ham verisinden (buffer) türünü tespit et
    const type = await fileTypeFromBuffer(req.file.buffer);

    // Eğer tür tespit edilemezse veya tespit edilen tür bir resim değilse hata ver
    if (!type || !type.mime.startsWith('image/')) {
      console.error('Detected MIME type is not an image:', type ? type.mime : 'unknown');
      return res.status(400).json({ error: 'Unsupported file type. Only images are allowed.' });
    }

    // Tespit edilen doğru MIME türünü kullan
    const mimeType = type.mime;
    console.log(`File type detected successfully: ${mimeType}`);
    // =================================================================

    const base64Image = req.file.buffer.toString('base64');
    const dataUrl = `data:${mimeType};base64,${base64Image}`;
    
    console.log("Sending to OpenAI for analysis...");
    
    const response = await openai.chat.completions.create({
      model: 'gpt-4o', 
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'text',
              // FİNAL VE EN GÜÇLÜ PROMPT
              text: `
                You are "RoomGuard", a world-class safety inspector. Your primary and most critical task is to analyze the provided image, identify all potential safety hazards, and return their exact coordinates NOT THAT DEEP.

                For each hazard found, you MUST provide all of the following fields:
                1.  **coordinates**: This is the MOST IMPORTANT field. Provide the hazard's central coordinates on the image as percentage values for x and y. Example: {"x": 50, "y": 25}. This field CANNOT be omitted.
                2.  **id**: A unique ID like "haz_01".
                3.  **category**: Such as 'electrical', 'fallAndTrip', etc.
                4.  **severity**: 'Low', 'Medium', or 'High'.
                5.  **description**: A detailed description of the hazard.
                6.  **remediation**: A practical step to fix the hazard.
                7.  **oshaStandard**: The relevant OSHA code.

                After identifying all hazards, provide overall and category scores, and fun facts.
                Your response MUST be a single, valid JSON object and nothing else. Do not wrap it in markdown backticks.
                The JSON structure must be exactly as follows, paying critical attention to including the 'coordinates' object for every single hazard:

                {
                  "scores": { "overall": 0, "categories": { "fallAndTrip": 0, "electrical": 0, "fireEgress": 0 }},
                  "hazards": [
                    {
                      "id": "haz_01",
                      "category": "...",
                      "severity": "...",
                      "description": "...",
                      "remediation": "...",
                      "oshaStandard": "...",
                      "coordinates": { "x": 0, "y": 0 }
                    }
                  ],
                  "funFacts": { "safestSpot": "", "earthquakeTip": "" }
                }
              `
            },
            {
              type: 'image_url',
              image_url: {
                url: dataUrl,
              },
            },
          ],
        },
      ],
      max_tokens: 1500,
    });

    console.log("Analysis received from OpenAI.");
    let analysisResult;
    try {
      analysisResult = JSON.parse(response.choices[0].message.content);
    } catch (parseError) {
      console.error("Failed to parse JSON from OpenAI:", response.choices[0].message.content);
      throw new Error("Invalid JSON response from AI.");
    }

    res.json(analysisResult);

  } catch (error) {
    console.error("Error during analysis:", error);
    res.status(500).json({ 
      error: 'Failed to analyze image.', 
      details: error.message 
    });
  }
});

app.listen(port, () => {
  console.log(`RoomGuard Backend server running at http://localhost:${port}`);
});