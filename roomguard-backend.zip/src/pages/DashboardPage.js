// src/pages/DashboardPage.js
import React, { useState, useEffect } from 'react';
import { useLocation, Link } from 'react-router-dom';

// Bileşenleri import ediyoruz
import InteractiveViewer from '../features/analysis/InteractiveViewer';
import Scorecard from '../features/analysis/Scorecard';
import HazardListItem from '../features/analysis/HazardListItem';
import HazardDetails from '../features/analysis/HazardDetails';
import ScoreHero from '../features/analysis/ScoreHero'; // YENİ KAHRAMAN BİLEŞENİ

function DashboardPage() {
  const location = useLocation();
  const [analysisData, setAnalysisData] = useState(null);
  const [selectedHazard, setSelectedHazard] = useState(null);

  useEffect(() => {
    if (location.state && location.state.analysisData) {
      const data = location.state.analysisData;
      setAnalysisData(data);
      if (data.hazards && data.hazards.length > 0) {
        setSelectedHazard(data.hazards[0]);
      }
    }
  }, [location.state]);

  const handleHazardSelect = (hazard) => {
    setSelectedHazard(hazard);
  };

  if (!analysisData) {
    return (
      <div className="loading-container">
        <h2>Analyzing Room...</h2>
        <p>This may take a moment.</p>
      </div>
    );
  }

  const imageUrl = location.state?.uploadedImage;

  return (
    // Yeni ana yerleşimimiz
    <div className="salt-layout">
      {/* SOL PANEL: Büyük skor göstergesi */}
      <div className="salt-hero-panel">
        <ScoreHero score={analysisData.scores.overall} />
      </div>

      {/* SAĞ PANEL: Resim ve diğer tüm detaylar */}
      <div className="salt-details-panel">
        <InteractiveViewer
          imageUrl={imageUrl}
          hazards={analysisData.hazards}
          onMarkerClick={handleHazardSelect}
          selectedHazardId={selectedHazard?.id}
        />
        
        <div className="details-section">
          <h4>Category Scores</h4>
          <Scorecard scores={analysisData.scores} />
        </div>

        <div className="details-section">
          <h4>Detected Hazards</h4>
          <div className="hazard-list-container">
            {analysisData.hazards && analysisData.hazards.length > 0 ? (
              analysisData.hazards.map(h => 
                <HazardListItem
                  key={h.id} 
                  hazard={h}
                  isSelected={selectedHazard?.id === h.id}
                  onClick={() => handleHazardSelect(h)}
                />)
            ) : (
              <p>No hazards were detected. Great job!</p>
            )}
          </div>
        </div>

        <div className="details-section">
            <h4>Hazard Details</h4>
            <HazardDetails hazard={selectedHazard} />
        </div>
      </div>
    </div>
  );
}

export default DashboardPage;