// src/features/analysis/InteractiveViewer.js

import React from 'react';

function InteractiveViewer({ imageUrl, hazards, onMarkerClick, selectedHazardId }) {
  return (
    <div className="interactive-viewer">
      <img src={imageUrl || 'https://via.placeholder.com/800x600.png?text=Upload+an+Image'} alt="Analyzed room" />

      {hazards.map(hazard => (
        <div
          key={hazard.id}
          className={`hazard-marker ${selectedHazardId === hazard.id ? 'selected' : ''}`}
          style={{
            top: `${hazard.coordinates.y}%`,
            left: `${hazard.coordinates.x}%`,
          }}
          onClick={() => onMarkerClick(hazard)}
          title={hazard.description}
        >
          !
        </div>
      ))}
    </div>
  );
}

export default InteractiveViewer;