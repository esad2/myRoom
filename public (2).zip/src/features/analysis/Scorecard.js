// src/features/analysis/Scorecard.js
import React from 'react';
import { VscChecklist } from "react-icons/vsc"; // İkonu import et

function Scorecard({ scores }) {
  return (
    <div className="card scorecard">
      <h3><VscChecklist /> Safety Scores</h3> {/* İkonu başlığa ekle */}
      <div className="score-item">
        <strong>Overall:</strong>
        <span className="score-value">{scores.overall} / 100</span>
      </div>
      {Object.entries(scores.categories).map(([key, value]) => (
        <div className="score-item" key={key}>
          <span>{key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}:</span>
          <span className="score-value">{value} / 100</span>
        </div>
      ))}
    </div>
  );
}

export default Scorecard;