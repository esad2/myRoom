// src/features/analysis/InteractiveViewer.js
import React from 'react';

function InteractiveViewer({ imageUrl, hazards, onMarkerClick, selectedHazard, onImageClick }) {
  const selectedHazardId = selectedHazard?.id;

  return (
    <div className="interactive-viewer" onClick={onImageClick}>
      <img src={imageUrl || 'https://via.placeholder.com/1920x1080.png?text=Image+Not+Found'} alt="Analyzed room" />

      {/* İşaretleyiciler artık doğrudan resim üzerinde konumlanacak */}
      {hazards.map(hazard => (
        <div
          key={hazard.id}
          className={`hazard-marker ${selectedHazardId === hazard.id ? 'selected' : ''}`}
          style={{
            top: `${hazard.coordinates.y}%`,
            left: `${hazard.coordinates.x}%`,
          }}
          onClick={(e) => {
            e.stopPropagation(); // Resme tıklama olayını tetiklemesin diye
            onMarkerClick(hazard);
          }}
          title={hazard.description}
        >
          !
        </div>
      ))}
    </div>
  );
}

export default InteractiveViewer;