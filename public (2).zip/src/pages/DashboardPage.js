// src/pages/DashboardPage.js
import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { VscClose } from "react-icons/vsc";

// Bileşenleri import ediyoruz
import InteractiveViewer from '../features/analysis/InteractiveViewer';
import Scorecard from '../features/analysis/Scorecard';
import HazardListItem from '../features/analysis/HazardListItem';
import HazardDetails from '../features/analysis/HazardDetails'; // Detaylar için geri geldi!
import ScoreHero from '../features/analysis/ScoreHero';

function DashboardPage() {
  const location = useLocation();
  const [analysisData, setAnalysisData] = useState(null);
  const [selectedHazard, setSelectedHazard] = useState(null);

  useEffect(() => {
    if (location.state && location.state.analysisData) {
      setAnalysisData(location.state.analysisData);
      setSelectedHazard(null);
    }
  }, [location.state]);

  const handleHazardSelect = (hazard) => {
    setSelectedHazard(prev => prev && prev.id === hazard.id ? null : hazard);
  };

  const closeDrawer = () => {
    setSelectedHazard(null);
  };

  if (!analysisData) {
    return (
      <div className="loading-container">
        <h2>Analyzing Room...</h2>
        <p>This may take a moment.</p>
      </div>
    );
  }

  const imageUrl = location.state?.uploadedImage;

  return (
    <div className="dashboard-container">
      {/* Arka plan her zaman interaktif resim olacak */}
      <InteractiveViewer
        imageUrl={imageUrl}
        hazards={analysisData.hazards}
        onMarkerClick={handleHazardSelect}
        selectedHazard={selectedHazard}
        onImageClick={closeDrawer}
      />

      {/* SOLDAKİ YÜZEN KONTROL PANELİ */}
      <div className="main-panel">
        <div className="panel-section">
          <ScoreHero score={analysisData.scores.overall} />
        </div>
        <div className="panel-section">
          <Scorecard scores={analysisData.scores} />
        </div>
        <div className="panel-section">
          <h4>Detected Hazards</h4>
          <div className="hazard-list-container">
            {analysisData.hazards?.length > 0 ? (
              analysisData.hazards.map(h =>
                <HazardListItem
                  key={h.id}
                  hazard={h}
                  isSelected={selectedHazard?.id === h.id}
                  onClick={() => handleHazardSelect(h)}
                />)
            ) : (
              <p className="no-hazards-message">No hazards were detected!</p>
            )}
          </div>
        </div>
      </div>
      
      {/* ALTTAN AÇILAN DETAY ÇEKMECESİ */}
      {selectedHazard && (
        <div className="details-drawer">
          <button onClick={closeDrawer} className="close-drawer-btn">
            <VscClose />
          </button>
          <HazardDetails hazard={selectedHazard} />
        </div>
      )}
    </div>
  );
}

export default DashboardPage;