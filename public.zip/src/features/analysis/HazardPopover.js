// src/features/analysis/HazardPopover.js
import React from 'react';
import { VscWarning, VscInfo, VscTools, VscLaw } from "react-icons/vsc";

function HazardPopover({ hazard }) {
  if (!hazard) return null;

  const severityClass = hazard.severity.toLowerCase();

  return (
    <div className="hazard-popover">
      <div className={`popover-header ${severityClass}`}>
        <VscWarning />
        <h4>{hazard.category.replace(/([A-Z])/g, ' $1')} Hazard</h4>
      </div>
      <div className="popover-content">
        <p><strong><VscInfo className="popover-icon" /> Description:</strong> {hazard.description}</p>
        <p><strong><VscTools className="popover-icon" /> Recommended Fix:</strong> {hazard.remediation}</p>
        <p><strong><VscLaw className="popover-icon" /> OSHA Standard:</strong> {hazard.oshaStandard}</p>
      </div>
      <div className="popover-arrow"></div>
    </div>
  );
}

export default HazardPopover;