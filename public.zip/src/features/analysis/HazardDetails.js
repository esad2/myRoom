// src/features/analysis/HazardDetails.js
import React from 'react';
// İkonları import et
import { VscWarning, VscInfo, VscTools, VscLaw } from "react-icons/vsc";

function HazardDetails({ hazard }) {
  if (!hazard) {
    return <p className="details-placeholder">Select a hazard from the list or the image to see its details.</p>;
  }

  return (
    <div className="hazard-details-content">
      <h4>{hazard.category.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())} Hazard Details</h4>
      {/* Her detayın başına bir ikon ekle */}
      <p><VscWarning className="icon" /><strong>Severity:</strong> <span className={hazard.severity.toLowerCase()}>{hazard.severity}</span></p>
      <p><VscInfo className="icon" /><strong>Description:</strong> {hazard.description}</p>
      <p><VscTools className="icon" /><strong>Recommended Fix:</strong> {hazard.remediation}</p>
      <p><VscLaw className="icon" /><strong>OSHA Standard:</strong> {hazard.oshaStandard}</p>
    </div>
  );
}

export default HazardDetails;