// server.js

// 1. Gerekli paketleri çağır
const express = require('express');
const OpenAI = require('openai');
const cors = require('cors');
const multer = require('multer');
require('dotenv').config();

// 2. Uygulama ve ayarları yapılandır
const app = express();
const port = 3001;

app.use(cors());
app.use(express.json());

const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// 3. Ana Analiz Endpoint'i
app.post('/api/analyze', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No image file uploaded.' });
    }

    console.log("Image received. Detecting file type from buffer...");

    const { fileTypeFromBuffer } = await import('file-type');
    const type = await fileTypeFromBuffer(req.file.buffer);

    if (!type || !type.mime.startsWith('image/')) {
      console.error('Detected MIME type is not an image:', type ? type.mime : 'unknown');
      return res.status(400).json({ error: 'Unsupported file type. Only images are allowed.' });
    }

    const mimeType = type.mime;
    console.log(`File type detected successfully: ${mimeType}`);
    
    const base64Image = req.file.buffer.toString('base64');
    const dataUrl = `data:${mimeType};base64,${base64Image}`;
    
    console.log("Sending to OpenAI for analysis...");
    
    const response = await openai.chat.completions.create({
      model: 'gpt-4o', 
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'text',
              // YAZIM HATASI DÜZELTİLDİ
              text: `
                ## 1. YOUR PERSONA
                You are RoomGuard, an AI with the equivalent of a PhD in Environmental Health & Safety. You are meticulous, observant, and an expert in identifying residential safety hazards. Your primary goal is user safety through accurate detection.

                ## 2. CORE MISSION
                Your mission is to meticulously analyze the user-provided image of a room and identify EVERY potential safety hazard, from the obvious (e.g., exposed wires) to the subtle (e.g., a poorly placed rug, an object blocking an egress path).

                ## 3. THE CRITICAL TASK: HAZARD IDENTIFICATION & COORDINATES
                This is the most important part of your job. For EACH hazard you find, you MUST follow this internal thought process:

                * **Step A: Visually Locate & Describe.** Scan the image quadrant by quadrant (top-left, top-right, bottom-left, bottom-right). Verbally identify the hazard in your mind. Example: "I see a tangled mess of electrical cords on the floor behind the desk."
                * **Step B: Pinpoint the Epicenter.** Determine the single, central point of the hazard you just described. For the tangled cords, this would be the middle of the mess. For a blocked window, it's the center of the window.
                * **Step C: Calculate Percentage Coordinates.** Convert that central point into percentage-based coordinates. X is the percentage from the left edge of the image. Y is the percentage from the top edge. These MUST be numbers.
                * **Step D: Self-Correction.** Mentally double-check: "Do my coordinates \\\`{"x": 85, "y": 90}\\\` actually point to the bottom-right area where the cords are?" If not, recalculate. **COORDINATE ACCURACY IS PARAMOUNT. A misplaced marker is a failed analysis.**

                ## 4. SCORING PHILOSOPHY
                Maintain the fair scoring model:
                * Start all scores at 100.
                * Deduct points for each hazard from both 'overall' and the relevant 'category' score.
                * Deduction values: High Severity = 15 points; Medium Severity = 8 points; Low Severity = 3 points.

                ## 5. REQUIRED JSON OUTPUT
                Your final output MUST be a single, raw JSON object. It MUST start with { and end with }.
                **DO NOT WRAP THE RESPONSE IN MARKDOWN \`\`\`json ... \`\`\` TAGS. NO EXPLANATIONS BEFORE OR AFTER THE JSON.**

                {
                  "scores": { "overall": 100, "categories": { "fallAndTrip": 100, "electrical": 100, "fireEgress": 100 }},
                  "hazards": [
                    {
                      "id": "haz_01",
                      "coordinates": { "x": 0, "y": 0 },
                      "category": "...",
                      "severity": "...",
                      "description": "...",
                      "remediation": "...",
                      "oshaStandard": "..."
                    }
                  ],
                  "funFacts": { "safestSpot": "", "earthquakeTip": "" }
                }
              `
            },
            {
              type: 'image_url',
              image_url: {
                url: dataUrl,
              },
            },
          ],
        },
      ],
      max_tokens: 1500,
    });

    console.log("Analysis received from OpenAI.");
    let analysisResult;
    try {
      let rawResponse = response.choices[0].message.content;
      
      let cleanedResponse = rawResponse.trim();
      if (cleanedResponse.startsWith("```json")) {
        cleanedResponse = cleanedResponse.substring(7);
      }
      if (cleanedResponse.endsWith("```")) {
        cleanedResponse = cleanedResponse.slice(0, -3);
      }
      
      analysisResult = JSON.parse(cleanedResponse);

    } catch (parseError) {
      console.error("Failed to parse JSON from OpenAI:", response.choices[0].message.content);
      throw new Error("Invalid JSON response from AI.");
    }
    
    res.json(analysisResult);

  } catch (error) {
    console.error("Error during analysis:", error);
    res.status(500).json({ 
      error: 'Failed to analyze image.', 
      details: error.message 
    });
  }
});

app.listen(port, () => {
  console.log(`RoomGuard Backend server running at http://localhost:${port}`);
});