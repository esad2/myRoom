// server.js - Google Gemini Entegrasyonu

// 1. Gerekli paketleri çağır
const express = require('express');
const { GoogleGenerativeAI } = require("@google/generative-ai"); // OpenAI yerine Google paketi
const cors = require('cors');
const multer = require('multer');
require('dotenv').config();

// 2. Uygulama ve ayarları yapılandır
const app = express();
const port = 3001;

app.use(cors());
app.use(express.json());

const storage = multer.memoryStorage();
const upload = multer({ storage: storage }).array('images', 5);

// 3. Gemini AI İstemcisini Başlat
// .env dosyasından GEMINI_API_KEY'i okur
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" }); // Hızlı ve güçlü multimodal model

// 4. Ana Analiz Endpoint'i
app.post('/api/analyze', upload, async (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ error: 'No image files uploaded.' });
    }

    console.log(`${req.files.length} image(s) received. Processing for Gemini...`);

    // Gemini'nin istediği resim formatı: { inlineData: { data: base64, mimeType: ... } }
    const imagePromises = req.files.map(async (file) => {
      const { fileTypeFromBuffer } = await import('file-type');
      const type = await fileTypeFromBuffer(file.buffer);

      if (!type || !type.mime.startsWith('image/')) {
        console.warn(`Skipping a file because it is not an image: ${file.originalname}`);
        return null;
      }

      return {
        inlineData: {
          data: file.buffer.toString("base64"),
          mimeType: type.mime
        }
      };
    });

    const imageParts = (await Promise.all(imagePromises)).filter(Boolean);

    if (imageParts.length === 0) {
      return res.status(400).json({ error: 'No valid image files were uploaded.' });
    }

    // Gemini için hazırlanan Prompt Metni
    const prompt = `
        ## 1. YOUR PERSONA
        You are RoomGuard, an AI with the equivalent of a PhD in Environmental Health & Safety, powered by Google Gemini. You are meticulous, observant, and an expert in identifying residential safety hazards. Your primary goal is user safety through accurate detection.

        ## 2. CORE MISSION
        Analyze the following series of images of the same room from different angles. Synthesize the information from all images to build a comprehensive 3D mental model of the space. Identify every potential safety hazard.

        ## 3. CRITICAL TASK: HAZARD IDENTIFICATION & COORDINATES
        For EACH hazard, follow this internal process:
        * **Step A: Cross-Reference Images.** Locate a potential hazard. Use other images to confirm its nature.
        * **Step B: Pinpoint the Epicenter.** Based on the BEST view of the hazard, determine its central point.
        * **Step C: Calculate Coordinates from the BEST Image.** Choose the image that shows the hazard most clearly and calculate its percentage-based coordinates.
        * **Step D: Add Image Reference.** In the "description" of the hazard, mention which image was best (e.g., "As seen in Image 2...").
        * **COORDINATE ACCURACY IS PARAMOUNT.**

        ## 4. SCORING & JSON OUTPUT
        * Start all scores at 100. Deduct points for each hazard (High: 15, Medium: 8, Low: 3).
        * Your final output MUST be a single, raw JSON object. It MUST start with { and end with }.
        * **DO NOT WRAP THE RESPONSE IN MARKDOWN \`\`\`json ... \`\`\` TAGS.**

        JSON Structure:
        {
          "scores": { "overall": 100, "categories": { ... }},
          "hazards": [ { "id": "haz_01", "coordinates": { "x": 0, "y": 0 }, ... } ],
          "funFacts": { ... }
        }
    `;

    // Prompt metnini ve resim dizisini birleştir
    const requestParts = [prompt, ...imageParts];

    console.log("Sending prompt and images to Gemini API...");

    // Gemini API'ye isteği gönder
    const result = await model.generateContent(requestParts);
    const response = result.response;
    const rawResponseText = response.text();

    console.log("Analysis received from Gemini.");
    
    let analysisResult;
    try {
      // Gemini'den gelen yanıt markdown içerebilir, temizleyelim.
      let cleanedResponse = rawResponseText.trim().replace(/^```json\s*|```\s*$/g, '');
      analysisResult = JSON.parse(cleanedResponse);
    } catch (parseError) {
      console.error("Failed to parse JSON from Gemini:", rawResponseText);
      throw new Error("Invalid JSON response from AI.");
    }
    
    res.json(analysisResult);

  } catch (error) {
    console.error("Error during analysis with Gemini:", error);
    res.status(500).json({ 
      error: 'Failed to analyze image with Gemini.', 
      details: error.message 
    });
  }
});

app.listen(port, () => {
  console.log(`RoomGuard Backend server running at http://localhost:${port}`);
});